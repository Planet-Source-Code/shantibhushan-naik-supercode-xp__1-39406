***PLEASE RUN "SETUP.BAT" FOR AN AUTOMATED DEMONSTRATION OF SUPERCODEXP.***

Hello VB Developer,
--------------------------------------------------------------------------------------------------------------------
You have just now downloaded a great code for your use; SuperCodeXP. I find many VB Developer's struggling to use astonishing and wonderful features in their applications, but their search always ends up with either a Win32 API or a VC++ source. Learning Win32 APIs' is a another deep curve in life of a programmer, but programmers' today simply don't seem to find enough time and freedom to explore such code. I am a programmer too, and even I want my applications to be the best of breed in today's market. Unfortunately, for VB, many standard and professional features like those of MS Office2K/XP or VS6.0/.NET are only a dream. These user interfaces are complex and astonishing, yet much more rich looking and best in the market. Even VB Developers' want to use such looks in their applications, and that too in a a more professional way. Well fortunately SuperCodeXP has come to their rescue. Now VB Developer's can easily,
#1. Create and display WinXP style balloon tooltips,
#2. Access system trays and that too with balloon tooltips, like those of MSN Messenger or LAN Manager,
#3. Access Computer Information,
#4. Access User Information, My Documents, My Pictures, Program Files,
#5. Create MS Office 2K/XP and VS6.0/.NET style menus, exactly like those of Microsoft Office Family,
#6. Create radio menu bitmaps, professional looking checkmarks,
#7. Control window transparency,
#7. Even shutdown Windows programmatically,
And lots' more in just a *single* line of code. Really, in just a *single* line of code. To see it for yourself, please see the VB source. It was unpractical for me to demonstrate all those *wonderful* features in a single source. I recommend you to use Object Browser to determine all available features of SuperCodeXP.

You have *entire* source with you for scrutiny. I am a developer who loves Win32 APIs' and I want that maximum developers' benefit out of efforts that I have taken during all this time. Believe me, it took me almost 06 months total to achieve all the functionality that you see in front of you today. I sincerely feel that no other developer
should waste his/her own time to re-invent those features on his own again.

I understand that no software is bug-free. So this code may also have it's own bugs. I have made my maximum efforts to resolve, uncover bugs present, but I understand that I alone cannot do it, so if you find any bugs or have any suggestions, feature requests, please feel free to mail them to me. I will be responding to you personally by mail. I am always available for assistance through mail and online on chat. Please feel free to contact me anytime.

Thanks and enjoy the great code,
Shantibhushan
s.naik@ebsolutech.com
Making Developer's Life Easier.. !!

msn id: visitsb@hotmail.com
yahoo id: visitsb
aol id: visitnaik
--------------------------------------------------------------------------------------------------------------------